
    var percentColors = [
        { pct: 0.0, color: { r: 0xff, g: 0x00, b: 0 } },
        { pct: 0.5, color: { r: 0xff, g: 0xff, b: 0 } },
        { pct: 1.0, color: { r: 0x00, g: 0xff, b: 0 } } ];

    var getColorForPercentage = function(pct) {
        for (var i = 1; i < percentColors.length - 1; i++) {
            if (pct < percentColors[i].pct) {
                break;
            }
        }
        var lower = percentColors[i - 1];
        var upper = percentColors[i];
        var range = upper.pct - lower.pct;
        var rangePct = (pct - lower.pct) / range;
        var pctLower = 1 - rangePct;
        var pctUpper = rangePct;
        var color = {
            r: Math.floor(lower.color.r * pctLower + upper.color.r * pctUpper),
            g: Math.floor(lower.color.g * pctLower + upper.color.g * pctUpper),
            b: Math.floor(lower.color.b * pctLower + upper.color.b * pctUpper)
        };
        return 'rgb(' + [color.r, color.g, color.b].join(',') + ')';
        // or output as hex if preferred
    }
$(document).ready(function () {

    $(".show_conf").each(function() {
        var val = $(this).val();
        if($(this).is(":checked")) {
            $("li.L"+val).show();
        } else {
            $("li.L"+val).hide();

        }

    });

     $('.show_conf').change(function() {
        var val = $(this).val();
        if($(this).is(":checked")) {
           $("li.L"+val).show();
           if(val === "1") {
               showLinks();
           }
        } else {
            $("li.L"+val).hide();
            if(val === "1") {
               resetLinks()
            }
        }
      });


     function resetLinks() {
        $(".mention").addClass("blue");
        $(".space").hide();
        $(".mention.word").removeClass("selected");
     }

     function showLinks() {
         $(".mention").removeClass("blue");
         $(".mention.word").addClass("selected");
         $(".space").show();
     }


     function setPublicLinks() {
        $("a.mention").each(function() {
            if(typeof $(this).attr("href") !== 'undefined' &&  $(this).attr("href") !== null ) {
                $(this).attr("data-href", $(this).attr("href"));
                $(this).attr("href", $(this).attr("data-url"));
            }
        });
     }

     function resetPublicLinks() {
             $("a.mention").each(function() {
                if(typeof $(this).attr("href") !== 'undefined' &&  $(this).attr("href") !== null ) {
                    $(this).attr("href", $(this).attr("data-href"));
                    $(this).attr("data-href", "");
                }
             });
          }

     $("#download").click(function() {
        var title = $("#document-title").text();
        var head = [];
        head.push("<!DOCTYPE html>");
        head.push("<html lang='en'>");
        head.push("<head><meta charset='UTF-8'>");
        head.push("<title>"+title+"</title>");
        head.push("<style>");
        head.push("ol { list-style-type: none; margin: 0 !important; }");
        head.push(".mention.blue {color: #337ab7; }");
        head.push(".mention.blue.underline { border-bottom-color: #2e6da4;}");
        head.push(".mention.gray { color: #333 !important; border-bottom: 2px dotted #777 !important; }");
        head.push("</style>");
        head.push("</head>");
        head.push("<body>");
        head.push("<div>");

         var foot = "</body></html>";

        setPublicLinks();
        var uriContent = "data:application/octet-stream," + encodeURIComponent(head.join("\n"))+encodeURIComponent( $('#annotations').html()+foot );
        window.open(uriContent, title+'.html');
        resetPublicLinks();
     });
});